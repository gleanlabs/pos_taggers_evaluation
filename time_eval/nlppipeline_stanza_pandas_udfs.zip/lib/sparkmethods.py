from typing import Tuple
import re
from pyspark.sql.types import StructType, StructField, LongType, ArrayType, StringType
from pyspark.sql import DataFrame, Row
from pyspark.ml.feature import CountVectorizer, IDF
from pyspark.sql import functions as F
from pyspark.sql.functions import udf
from pyspark import SparkContext

from lib.nlppipelinenltk import NLPPipelineNLTK
from lib.utils.synonyms import create_synonym_list

newSchema = StructType([
    StructField("sentenceKeyPhrases",
                ArrayType(StructType([
                    StructField("sentence", StringType(), False),
                    StructField("keyphrases", ArrayType(StringType(), True))
                ])), False),
    StructField("docID", LongType(), False),
    StructField("content", StringType(), False)])

def stage1(df: DataFrame) -> DataFrame:
    """ Performs key phrase extraction
        1) Cleanup to ensure dataframe is ready for processing
        2) Key phrase extraction
        3) Removal of phrases considered irrelevant

    Parameters:
        df (Spark Dataframe): schema of ["docID", "content"]

    Returns:
        Transformation-ready dataframe schema of ["docID", "content", "sentencKeyPhrases"]
    """
    df = df.filter(df["content"] != "")
    dfKeyPhrases = processKeyPhrasesNLTK(df)
    return dfKeyPhrases

def stage2_remap(df: DataFrame) -> Tuple[DataFrame, DataFrame]:
    """ Remap to new schema

    Parameters:
        df (Spark Dataframe): schema of ["docID", "content", "sentenceKeyPhrases"]

    Returns:
        Transformation-ready dataframe schema of ["sentenceID","keyphrase"]
        Transformation-ready dataframe schema of ["docID","sentence","sentenceID"]
    """
    df = df.withColumn("data", F.explode("sentenceKeyPhrases")).select("docID", "data.*") \
        .filter(F.size("keyphrases") > 0).withColumn("sentenceID", F.monotonically_increasing_id())
    sentence_df = df.select("docID", "sentence", "sentenceID")
    kp_df = df.select("sentenceID", F.explode("keyphrases").alias("keyphrase"))
    return kp_df, sentence_df

def stage2_replace_synonym(spark: SparkContext, df: DataFrame, synonym_string) -> DataFrame:
    """
    Parameters:
        spark: SQLContext
        df: Spark Dataframe - schema has to have keyphrase column which is a string

    Returns:
        Transformation-ready dataframe schema of ["docID","sentence","keyphrase"]
    """
    trie = create_synonym_list(synonym_string)
    broadcastVar = spark.broadcast(trie)

    @udf("string")
    def synonynm_udf(s: str):
        return broadcastVar.value.search(s.strip().replace('-', ' '))

    return df.withColumn("keyphrase", synonynm_udf("keyphrase"))


def stage2_remove_common_skills_related_kps(df: DataFrame, df_skills: DataFrame) -> DataFrame:
    """
    Parameters:
        df: Spark Dataframe - schema has to have keyphrase column which is a string

    Returns:
        Transformation-ready dataframe schema of ["sentenceID","keyphrase"]
    """
    # common kps to remove next to skills
    common_kps = ['function', 'code', 'method', 'argument', 'parameter', 'project', 'script', 'variable']
    df_skills_common = df_skills.withColumn('skills_common', F.array(
        [F.concat(F.col('skill'), F.lit(' '), F.lit(common)) for common in common_kps] + [
            F.concat(F.lit(common), F.lit(' '), F.col('skill')) for common in common_kps]))
    df_skills_common_explode = df_skills_common.select(F.col('skill'),
                                                       F.explode(F.col('skills_common')).alias('skills_common'))
    df_skills_common_join = df.join(df_skills_common_explode,
                                    df_skills_common_explode.skills_common == df.keyphrase,
                                    'left')
    df_skills_common_join = df_skills_common_join.withColumn(
        "keyphrase",
        F.when(
            ~ F.col("skills_common").isNull(),
            F.col("skill")
        ).otherwise(F.col("keyphrase"))
    )
    return df_skills_common_join.select('sentenceID', 'keyphrase')


def stage3(df, vocabSize=12000000, minDFSize=3):
    """ Calculate TF for each key phrase

    Parameters:\n
        df (Spark Dataframe): schema of ["docID", "keyphrase"].\n
        vocabSize (int): Expected number of distinct key phrases in the whole corpus\n
        minDFSize (int): Number of documents that a key phrase should appear in order to be considered.
    Returns:\n
        Dataframe of schema ["phrases", "rawFeatures"],\n
        List[string]
    """
    joinedDF = df.groupBy("docID").agg(F.collect_list("keyphrase").alias("phrases"))
    countVectorizer = CountVectorizer(inputCol="phrases", outputCol="rawFeatures", vocabSize=vocabSize, minDF=minDFSize)
    model = countVectorizer.fit(joinedDF)
    df = model.transform(joinedDF).select("rawFeatures")
    return (df, model.vocabulary)


def stage3_min_count(df, minDFSize=2):
    df_filt = df.groupBy("keyphrase").agg(F.count("*").alias("count_kps")).where(F.col("count_kps") >= minDFSize)
    df_joined = df.join(df_filt, df.keyphrase == df_filt.keyphrase).select(df.sentenceID, df.keyphrase)
    return df_joined


def stage4(df: DataFrame) -> DataFrame:
    """ Calculate tfidf for each key phrase

    Parameters:
        df (Spark Dataframe): Schema of ["rawFeatures"] - Sparse vector of indices & tf values

    Returns:
        Transformation for dataframe of schema ["index", "tfidf"]
    """
    idf = IDF(inputCol="rawFeatures", outputCol="idf_features")
    idfModel = idf.fit(df)
    tfidf = idfModel.transform(df)
    mappedDF = tfidf.rdd.map(lambda x: Row(indices=x["idf_features"].indices.tolist(), \
                                           values=x["idf_features"].values.tolist())).toDF()
    return mappedDF.withColumn("vars", F.explode(F.arrays_zip(F.col("indices"), F.col("values")))) \
        .select(F.col("vars.indices").alias("index"), F.col("vars.values").alias("tfidf"))


def stage5(df: DataFrame, stdMultiplier: int) -> DataFrame:
    """ Find the relevant keyphrases by averaging the tfidf score for each unique key phrase,
        calculating the avg and std of all key phrase tfidf averages and then setting a threshold which
        is the average + std * stdMultiplier.

    Parameters:
        df (Spark Dataframe): Schema of ["index", "tfidf"].

    Returns:
        Tuple3 [avg, std, std threshold]\n
        Spark Dataframe unique key phrase indices\n
        Spark Dataframe removed unique key phrase indices
    """
    avgtfidfDF = df.groupBy("index").agg(F.avg("tfidf").alias("avgtfidf"))
    kpAvg = avgtfidfDF.agg(F.avg('avgtfidf')).rdd.flatMap(lambda x: x).collect()[0]
    kpStddev = avgtfidfDF.agg(F.stddev('avgtfidf')).rdd.flatMap(lambda x: x).collect()[0]
    thresholdSTD = float(kpStddev) * stdMultiplier
    useDF = df.groupBy("index").agg(F.max("tfidf")).filter(F.col("max(tfidf)") >= thresholdSTD).select("index")
    throwoutDF = df.groupBy("index").agg(F.max("tfidf")).filter(F.col("max(tfidf)") < thresholdSTD).select("index")
    return ([kpAvg, kpStddev, thresholdSTD], useDF, throwoutDF)


def stage6(includedKeyPhrasesDF: DataFrame, vocbularyDF: DataFrame, so_kps_byidDF: DataFrame) -> DataFrame:
    """ Filters out the corpus keyphrases which are excepted

    Parameters:
        includedKeyPhrasesDF (Spark Dataframe): Schema of ["index"] - The key phrases that should be included\n
        vocbularyDF (Spark Dataframe): Schema of ["id", "value"] - The full vocabulary created\n
        so_kps_byidDF (Spark Dataframe): Schema of ["docID", "keyphrase"] - The mapping of keyphrase to docID for the corpus

    Returns:
        Transformation for Dataframe schema ["docID", "keyphrase"]
    """
    includedPhrasesDF = vocbularyDF.join(includedKeyPhrasesDF, vocbularyDF.id == includedKeyPhrasesDF.index).select(
        vocbularyDF.value, vocbularyDF.id)
    return so_kps_byidDF.join(includedPhrasesDF, so_kps_byidDF.keyphrase == includedPhrasesDF.value) \
        .select(so_kps_byidDF.docID, includedPhrasesDF.value.alias("keyphrase"),
                includedPhrasesDF.id.alias("keyphraseID"))


def processRowsNLTK(rows):
    nlpPipeline = NLPPipelineNLTK()  # initialize the class once per partition
    return ((nlpPipeline.getKeyPhrases(r.content), *r)
            for r in rows)  # reuses the same NLPPipeline instance for all rows in this partition

def processKeyPhrasesNLTK(df: DataFrame) -> DataFrame:
    """Returns content as key phrases"""
    return df.rdd.mapPartitions(processRowsNLTK) \
        .toDF(schema=newSchema)

def explode_kps(row):
    content_rows = [Row(keyphrase=keyphrase, sentenceID=row.sentenceID) for kps in row.keyphrasesArr for keyphrase in kps]
    return content_rows

def createVocabulary(spark, vocabulary) -> DataFrame:
    """
    Parameters:
        spark: SQLContext
        vocabulary: List[string]
    Returns:
        Transformation-ready dataframe of ["value", "id"]
    """
    vocDF = spark.createDataFrame(vocabulary, StringType())
    vocDF_withIndex = vocDF.withColumn("id", F.lit(1))
    vocDF_withIndex = vocDF_withIndex.rdd.map(lambda r: r.value).zipWithIndex().toDF(['value', 'id'])
    return vocDF_withIndex