import nltk
import stanza

from .nlppipeline import NLPPipeline
from .tokenizer.treebankwordtokenizer import RevisedTreeBankWordTokenizer
import os
import torch

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
torch.set_num_threads(1)


class NLPPipelineNLTK(NLPPipeline):

    def __init__(self):
        super(NLPPipelineNLTK, self).__init__()
        self.__tokenizer = RevisedTreeBankWordTokenizer()
        self.nlp = stanza.Pipeline(lang='en', processors='tokenize,pos', tokenize_pretokenized=True)

    def preprocessDocument(self, document):
        import numpy as np
        # separatedSentences = nltk.sent_tokenize(document)
        sentences_tok = [self.__tokenizer.tokenize(sent) for sent in document]
        sentences = [[(word.text, word.xpos) for word in s.words] for s in self.nlp(sentences_tok).sentences]
        grammar = r"""
      NBAR:
          # Nouns and Adjectives, terminated with Nouns and optionally numbers
          {<NN.*|JJ>*<NN.*><CD>?<SYM>?}
      NP:
          {<NBAR>}
          {<NBAR><IN><NBAR>}  # Above, connected with in/of/etc...
    """
        chunker = nltk.RegexpParser(grammar)
        trees = [chunker.parse(sent) for sent in sentences]
        return trees, document
