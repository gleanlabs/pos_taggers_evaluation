import csv

from lib.utils.trie import Trie

def create_synonym_list(input_file: str):
    lines = list(csv.reader(input_file.splitlines(), delimiter=','))
    trie = Trie()
    for line in lines:
        trie.insert(line[0].replace('-',' '), line[1].replace('-',' '))
    return trie



