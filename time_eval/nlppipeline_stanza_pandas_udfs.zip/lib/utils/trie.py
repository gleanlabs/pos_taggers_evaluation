import logging
import os
from codecs import encode
from collections import defaultdict

MINIMAL_TRIE_UNICODE_CHAR = 20 # <space> is the first unicode character which is possible

class TrieNode():
    def __init__(self):
        self.end_of_word = None
        self.children = defaultdict()

    def __str__(self):
        if self.children == {}:
            return ""
        else:
            s = '{'
            comma = False
            for i in self.children:
                if comma:
                    s = s + ','
                else:
                    comma = True
                s = s + f"'{chr(i+MINIMAL_TRIE_UNICODE_CHAR)}'{self.children[i].__str__()}"
            s = s + '}'
        return s

    def get_index(self, ch) -> int:
        if (ord(ch) < MINIMAL_TRIE_UNICODE_CHAR):
            raise IndexError("Character is below range")
        return ord(ch) - MINIMAL_TRIE_UNICODE_CHAR

class Trie():
    def __init__(self, pairs=None):
        self.__head = TrieNode()
        if pairs:
            for word in pairs:
                self.insert(word[0], word[1])

    def __str__(self):
        return self.__head.__str__()

    def insert(self, word, synonym):
        root = self.__head
        length = len(word) 
        for i in range(length):
            index = root.get_index(word[i])
            if index not in root.children:
                root.children[index] = TrieNode()
            root = root.children.get(index)

        root.end_of_word = synonym

    def search(self, word) -> str:
        root = self.__head
        length = len(word)
        for level in range(length):
            try:
                index = root.get_index(word[level])
            except IndexError as e:
                logging.error(f'Word searched for has invalid character in location {level+1}: {":".join("{:02x}".format(c) for c in word.encode("utf-8"))}')
                return word
            if not root.children.get(index):
                return word
            root = root.children[index] 
        if root != None and root.end_of_word != None:
            return root.end_of_word
        return word
