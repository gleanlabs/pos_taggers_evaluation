import nltk
from .nlppipeline import NLPPipeline
import en_core_web_sm
from .tokenizer.treebankwordtokenizer import RevisedTreeBankWordTokenizer

class NLPPipelineNLTK(NLPPipeline):

    def __init__(self):
        super(NLPPipelineNLTK, self).__init__()
        self.nlp = en_core_web_sm.load()
        self.nlp.tokenizer = RevisedTreeBankWordTokenizer(self.nlp.vocab)

    def preprocessDocument(self, document):
        separatedSentences = nltk.sent_tokenize(document)
        sentences = [self.nlp(sentence) for sentence in separatedSentences]
        sentencesPos = [[(word.text, word.tag_) for word in sentence] for sentence in sentences]