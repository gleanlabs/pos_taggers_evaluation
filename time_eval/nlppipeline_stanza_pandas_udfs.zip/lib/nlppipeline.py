from collections import defaultdict
import re

import nltk
# nltk.download('wordnet')
# nltk.download('punkt')
# nltk.download('averaged_perceptron_tagger')
from nltk.corpus import wordnet

from .stopwords import STOP_WORDS


class NLPPipeline():
    def __init__(self):
        self.__lemmatizer = nltk.WordNetLemmatizer()
        self.__tagMap = defaultdict(lambda: wordnet.NOUN)
        self.__tagMap['J'] = wordnet.ADJ
        self.__tagMap['V'] = wordnet.VERB
        self.__tagMap['R'] = wordnet.ADV
        self.__specialCharPatternStart = re.compile("""^[#\[\]\{\}\,\'%\$\-\+\*=><]""")
        self.__specialCharPattern = {'reg_bad_end': re.compile(".+[;!]$"),
                                     'reg_equal': re.compile(".+=="),
                                     'regex_repeat_letters': re.compile(r"(\w)\1{2,}"),
                                     'one_letters': re.compile(r"\b[abd-qs-zABD-QS-Z]\b")}
    def preprocessDocument(self, document):
        pass

    def __leaves(self, tree):
        """Finds NP (nounphrase) leaf nodes of a chunk tree."""
        for subtree in tree.subtrees(filter=lambda t: t.label() == 'NP'):
            yield subtree.leaves()

    def __normalise(self, word, pos):
        """Lemmatize words and lowercase them"""
        if not word.endswith('ss') and not len(word) == 2:
            newWord = self.__lemmatizer.lemmatize(word, self.__tagMap[pos[0]])
            return newWord.lower(), word
        else:
            return word.lower(), word

    def __acceptable_word(self, word):
        """Checks conditions for acceptable word"""
        accepted = bool(len(word) <= 18 and (word.lower() not in STOP_WORDS) \
                        and (not re.match(self.__specialCharPatternStart, word)) and not (
                    ('\\' in word) or ('/' in word)))
        for regex in self.__specialCharPattern.values():
            if re.search(regex, word):
                accepted = False
                break
        return accepted

    def __getTerms(self, tree):
        for leaf in self.__leaves(tree):
            term = [self.__normalise(w, t)
                    for w, t in leaf if self.__acceptable_word(w)]
            yield term

    def __reviseSentence(self, sentence: str, terms):
        keyPhraseSequences = [word for word in terms if word]
        keyPhrases = []
        for kpPairs in keyPhraseSequences:
            keyPhrase = " ".join([tup[0] for tup in kpPairs])
            origKeyPhrase = " ".join([tup[1] for tup in kpPairs])
            sentence = re.sub("(?:(?<=^)|(?<=[\s,.:;\"\']))%s(?:(?=$)|(?=[\s,.:;\"\']))" % re.escape(origKeyPhrase),
                              keyPhrase, sentence)
            keyPhrases.append(keyPhrase)
        return keyPhrases, sentence

    def getKeyPhrases(self, data: str) -> list:
        if (data == None) or (data == ''):
            return []
        trees, sentences = self.preprocessDocument(data)
        response = []
        for tree, sentence in zip(trees, sentences):
            terms = self.__getTerms(tree)
            keyPhrases, sentence = self.__reviseSentence(sentence, terms)
            response.append((sentence, keyPhrases))
        return response
